package com.aric.samples.exceptions;

public class AritmeticException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = 3643181441899255857L;

    public AritmeticException(final String message) {
        super(message);
    }

}
